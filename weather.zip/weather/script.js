const apiKey="60179923523d15e1ceebec27e7b4309a";
const apiUrl="https://api.openweathermap.org/data/2.5/weather?units=metric&q=";

const searchBox = document.querySelector(".search input");
const searchBtn = document.querySelector(".search button");
const weatherIcon = document.querySelector(".weather-icon");

async function check(city) {
    const res = await fetch(apiUrl + city + `&appid=${apiKey}`);
    // in data we have store all the data of the api
    var data = await res.json(); 
    // print the data into console
    console.log(data);
    //update the city name
    document.querySelector(".city").innerHTML = data.name;
    //update the temperature
    document.querySelector(".temp").innerHTML =Math.round(data.main.temp) + "°C";
    //update the humidity
    document.querySelector(".humidity").innerHTML = data.main.humidity + "%";
    //update the wind speed
    document.querySelector(".wind").innerHTML = data.wind.speed + " km/h";

    if(data.weather[0].main == "Clear") {
        weatherIcon.src = "images/clear.png";
    } 
    else if(data.weather[0].main == "Clouds") {
        weatherIcon.src = "images/clouds.png";
    } 
    else if(data.weather[0].main == "Rain") {
        weatherIcon.src="images/rain.png";
    } 
    else if(data.weather[0].main == "Snow") {
        weatherIcon.src= "images/snow.png";
    } 
    else if(data.weather[0].main == "Thunderstorm") {
        weatherIcon.src = "images/thunderstorm.png";
    } 
    else if(data.weather[0].main == "Haze") {
        weatherIcon.src="images/drizzle.png";
    } 
    else if(data.weather[0].main == "Mist") {
        weatherIcon.src = "images/mist.png";
    } 
    else if(data.weather[0].main == "Smoke") {
        weatherIcon.src = "images/smoke.png";
    } 
    else {
        weatherIcon.src= "images/clear.png";
    }
}


//send the input data to check()
searchBtn.addEventListener("click", () => {
    //get the value entered in search Box by the user
    check(searchBox.value);
});
